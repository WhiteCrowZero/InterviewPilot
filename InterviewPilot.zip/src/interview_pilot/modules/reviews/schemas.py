"""Pydantic schemas for mistakes."""
