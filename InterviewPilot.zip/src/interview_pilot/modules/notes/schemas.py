"""Pydantic schemas for notes."""
