"""Notes module."""
