"""Database models for notes."""
