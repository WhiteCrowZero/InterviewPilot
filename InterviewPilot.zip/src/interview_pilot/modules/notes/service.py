"""Notes domain business logic."""
