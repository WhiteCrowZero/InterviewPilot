"""Auth domain business logic."""
