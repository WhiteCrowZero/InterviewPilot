from contextlib import asynccontextmanager

from fastapi import FastAPI

from interview_pilot.api.v1.router import api_router
from interview_pilot.core.config import settings


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        lifespan=lifespan,
    )
    app.include_router(
        api_router,
        prefix=f"{settings.api_prefix}/{settings.api_version}"
    )
    return app


app = create_app()
