from __future__ import annotations

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from interview_pilot.core.config import settings
from interview_pilot.db.base import Base
import interview_pilot.db.models  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)


def get_sync_database_url() -> str:
    if settings.database_url.startswith("sqlite"):
        return settings.database_url.replace("+aiosqlite", "")
    elif settings.database_url.startswith("mysql"):
        return settings.database_url.replace("+aiomysql", "")
    elif settings.database_url.startswith("postgresql"):
        return settings.database_url.replace("+asyncpg", "")
    else:
        raise ValueError("Unsupported database URL")


target_metadata = Base.metadata
config.set_main_option("sqlalchemy.url", get_sync_database_url())


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
