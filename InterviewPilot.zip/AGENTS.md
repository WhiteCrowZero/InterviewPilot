# Python Backend Project Agent Rules

## 1. Project Principles

> Product goals come first. Technical choices must serve real project needs.

Treat this project as a small-to-medium Python backend project by default. Prioritize:

- Simplicity and clarity
- Runnable and maintainable code
- Gradual extensibility

Do not over-engineer or introduce premature abstractions.

Confirm with the user before making any important design decision, complex implementation, new dependency, or new architecture.

---

## 2. Development Workflow

Follow MVP-first and small-step iteration:

1. Build the minimum runnable version first.
2. Then create the minimum project structure.
3. Improve core modules step by step.
4. Add non-core features only after the core flow is stable.

Handle only one clear target at a time, such as one feature, one bug, one API, or one small module improvement.

Do not directly perform large-scale changes, full rewrites, or multi-module refactors.

If the request is too large, first split it into smaller tasks or create a concrete plan. Write the plan into a Plan document, clarify requirements with the user, and wait for user confirmation before editing code.

---

## 3. Tools and Environment

Development tools:

- Dependency management: `uv`
- Testing: `pytest`

Use uv-native commands by default, such as:

```bash
uv add
uv remove
uv run
````

Do not use `uv pip` by default unless the user explicitly asks for it.

---

## 4. Verification and Testing

Runtime code changes must include verification.

Do not add tests blindly or create excessive tests.

New tests should cover only the most important core paths. Confirm with the user before adding more tests.

Watch for test timeouts. If tests hang for too long, stop waiting, explain where they got stuck, and suggest the next debugging step.

---

## 5. Special Rules

### Git

* Do not perform any Git write operations.
* Only Git read operations are allowed.
* You may suggest branch names and commit messages, but must not execute them.

### Coding Style

* Use clear and accurate type annotations in Python code whenever possible.
* Avoid `Any` unless the type cannot be expressed accurately.
* Add this to new Python files by default:

```python
from __future__ import annotations
```

### WSL and Windows

The development environment is in WSL and is isolated from the actual Windows code environment.

- Current directory: `~/projects/InterviewPilot/`
- Windows directory: `/mnt/d/ComputerScience/Python/temp/InterviewPilot/`

---

## 6. Project Structure

This is the main structure of the current project, which will be continuously iterated as the project develops. Every major structural adjustment needs to be updated in a timely manner:

```txt

```
