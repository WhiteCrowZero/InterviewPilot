import time
from functools import wraps


def retry(times=3, delay=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_error = None

            for i in range(times):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    print(f"第 {i + 1} 次调用失败：{e}")

                    if i < times - 1:
                        time.sleep(delay)

            raise last_error

        return wrapper

    return decorator


@retry(times=3, delay=0.5)
def call_payment_api():
    print("调用支付接口")
    raise TimeoutError("支付接口超时")


# call_payment_api()